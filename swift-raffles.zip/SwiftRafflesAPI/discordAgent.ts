import Discord from "discord.js";
//
// export default class DiscordAgent {
//   private token: string;
//
//   constructor(token: string) {
//     this.token = token;
//     Discord.Guild.prototype.toJSON().then(r => console.log(r));
//   }
//
// }